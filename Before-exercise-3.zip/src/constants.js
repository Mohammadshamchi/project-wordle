export const NUM_OF_GUESSES_ALLOWED = 6;
